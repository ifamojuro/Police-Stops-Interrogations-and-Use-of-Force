##Online Data Sources

- The Washington Post Maintains a database of Fatal Police Shootings from 2015-2016 here: https://github.com/washingtonpost/data-police-shootings 