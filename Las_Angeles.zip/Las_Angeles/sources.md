Data -> Sources:
Arrest Records from 2010 to Present (4/15/18) -> https://catalog.data.gov/dataset/arrest-data-from-2010-to-present
Veichle and Pedestrian Stop Data -> https://catalog.data.gov/dataset/lapd-vehicle-and-pedestrian-stops-2010-present