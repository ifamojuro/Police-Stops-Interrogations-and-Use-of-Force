## Data -> Source
Complaints made against police officers.csv -> https://data.cityofchicago.org/Public-Safety/COPA-Cases-By-Involved-Officer/ufxy-tgry
Stop and Frisk Data -> https://home.chicagopolice.org/isr-data/